from pathlib import Path
from fest_registration.processor import process_files
from fest_registration.writer import write_outputs

if __name__ == "__main__":
    base = Path(__file__).parent
    input_dir = base / "input"
    department_files = [input_dir / name for name in
                        ("cse.txt", "ece.txt", "aids.txt", "mech.txt", "civil.txt")]
    records, events, errors, stats = process_files(department_files)
    output_dir = base / "output"
    write_outputs(records, events, errors, stats, output_dir)
    print("COLLEGE FEST REGISTRATION PROCESSING")
    print("Files successfully read:", stats["files_read"])
    print("Valid unique registrations:", len(records))
    print("Duplicates:", stats["duplicates"])
    print("Invalid e-mails:", stats["invalid_emails"])
    print("Damaged records:", stats["damaged"])
    print("Events generated:", ", ".join(sorted(events)) or "None")
    print("File-level / record errors:", len(errors))
    print("Output folder:", output_dir.resolve())
