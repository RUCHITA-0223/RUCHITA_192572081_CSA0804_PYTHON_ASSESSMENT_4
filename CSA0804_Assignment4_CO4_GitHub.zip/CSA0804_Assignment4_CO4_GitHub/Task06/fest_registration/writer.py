import csv
from pathlib import Path

def write_outputs(records, event_map, errors, stats, output_dir):
    root = Path(output_dir)
    event_dir = root / "events"
    event_dir.mkdir(parents=True, exist_ok=True)
    with (root / "master.csv").open("w", newline="", encoding="utf-8") as file:
        writer = csv.writer(file)
        writer.writerow(["Register Number", "Name", "Department", "Email", "Events"])
        for record in records:
            writer.writerow([record["reg_no"], record["name"], record["department"],
                             record["email"], ";".join(record["events"])])
    for event, participants in event_map.items():
        safe_name = "".join(c for c in event if c.isalnum() or c in "-_") or "event"
        with (event_dir / f"{safe_name}.txt").open("w", encoding="utf-8") as file:
            for record in participants:
                file.write(f'{record["reg_no"]}, {record["name"]}, {record["department"]}\n')
    with (root / "summary.txt").open("w", encoding="utf-8") as file:
        file.write(f"Valid unique registrations: {len(records)}\n")
        file.write(f'Duplicates: {stats["duplicates"]}\n')
        file.write(f'Invalid e-mails: {stats["invalid_emails"]}\n')
        file.write(f'Damaged records: {stats["damaged"]}\n')
        file.write(f'Files read: {stats["files_read"]}\n')
        for event, participants in sorted(event_map.items()):
            file.write(f"{event}: {len(participants)}\n")
    with (root / "errors.log").open("w", encoding="utf-8") as file:
        for path, line_no, reason, raw in errors:
            file.write(f"{path}:{line_no}: {reason} | {raw}\n")
