from .exceptions import InvalidRecord

def valid_email(email):
    email = email.strip()
    if " " in email or email.count("@") != 1:
        return False
    local, domain = email.split("@")
    return bool(local and domain and "." in domain
                and not domain.startswith(".") and not domain.endswith("."))

def parse_record(line):
    parts = [part.strip() for part in line.rstrip("\n").split(",")]
    if len(parts) != 5:
        raise InvalidRecord(f"expected 5 fields, found {len(parts)}")
    reg_no, name, department, email, event_text = parts
    if not all((reg_no, name, department, email, event_text)):
        raise InvalidRecord("one or more required fields are empty")
    if not valid_email(email):
        raise InvalidRecord(f"invalid email '{email}'")
    events = [event.strip() for event in event_text.split(";") if event.strip()]
    if not events:
        raise InvalidRecord("no valid event selected")
    return {"reg_no": reg_no, "name": name, "department": department,
            "email": email, "events": events}
