class InvalidRecord(Exception):
    """Raised when a fest registration row is invalid."""
