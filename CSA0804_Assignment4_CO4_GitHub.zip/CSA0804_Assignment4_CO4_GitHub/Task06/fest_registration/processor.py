from .validator import parse_record
from .exceptions import InvalidRecord

def process_files(paths):
    seen, records, event_map, errors = set(), [], {}, []
    stats = {"duplicates": 0, "invalid_emails": 0, "damaged": 0, "files_read": 0}
    for path in paths:
        try:
            with open(path, "r", encoding="utf-8") as source:
                stats["files_read"] += 1
                for line_no, line in enumerate(source, start=1):
                    if not line.strip():
                        continue
                    try:
                        record = parse_record(line)
                    except InvalidRecord as error:
                        stats["damaged"] += 1
                        if "invalid email" in str(error):
                            stats["invalid_emails"] += 1
                        errors.append((str(path), line_no, str(error), line.rstrip()))
                        continue
                    reg_no = record["reg_no"]
                    if reg_no in seen:
                        stats["duplicates"] += 1
                        errors.append((str(path), line_no, "duplicate registration", line.rstrip()))
                        continue
                    seen.add(reg_no)
                    records.append(record)
                    for event in record["events"]:
                        event_map.setdefault(event, []).append(record)
        except FileNotFoundError as error:
            errors.append((str(path), "-", f"missing file: {error}", ""))
        except PermissionError as error:
            errors.append((str(path), "-", f"permission denied: {error}", ""))
        except UnicodeDecodeError as error:
            errors.append((str(path), "-", f"invalid UTF-8: {error}", ""))
        except OSError as error:
            errors.append((str(path), "-", f"file error: {error}", ""))
    return records, event_map, errors, stats
