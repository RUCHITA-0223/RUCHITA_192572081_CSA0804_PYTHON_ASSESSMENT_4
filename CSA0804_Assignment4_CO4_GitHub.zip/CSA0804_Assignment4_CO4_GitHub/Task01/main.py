from decimal import Decimal, InvalidOperation
from pathlib import Path

def process_mess_file(filename, output_dir="output"):
    total = Decimal("0.00")
    report_rows, rejected_lines = [], []
    path = Path(filename)
    try:
        with path.open("r", encoding="utf-8") as file:
            for line_number, line in enumerate(file, start=1):
                if not line.strip():
                    continue
                parts = [part.strip() for part in line.rstrip("\n").split(",")]
                if len(parts) != 3:
                    rejected_lines.append((line_number, line.rstrip(), "Expected exactly 3 fields"))
                    continue
                reg_no, name, amount_text = parts
                if not reg_no or not name:
                    rejected_lines.append((line_number, line.rstrip(), "Register number and name are required"))
                    continue
                try:
                    amount = Decimal(amount_text)
                    if not amount.is_finite() or amount < 0:
                        raise ValueError("Amount must be a finite non-negative value")
                except (InvalidOperation, ValueError) as error:
                    rejected_lines.append((line_number, line.rstrip(), str(error)))
                    continue
                total += amount
                report_rows.append((reg_no, name, amount))
    except FileNotFoundError:
        print(f"Error: file not found: {path}")
        return [], Decimal("0.00"), []

    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    with (out / "mess_report.txt").open("w", encoding="utf-8") as report:
        for reg_no, name, amount in report_rows:
            report.write(f"{reg_no} | {name} | {amount:.2f}\n")
        report.write(f"TOTAL: {total:.2f}\n")
    with (out / "rejected_lines.log").open("w", encoding="utf-8") as log:
        for number, raw, reason in rejected_lines:
            log.write(f"Line {number}: {reason} | {raw}\n")

    print("HOSTEL MESS BILL PROCESSING")
    for reg_no, name, amount in report_rows:
        print(f"{reg_no} | {name} | {amount:.2f}")
    print(f"Valid records: {len(report_rows)}")
    print(f"Total amount: {total:.2f}")
    print(f"Rejected records: {len(rejected_lines)}")
    for item in rejected_lines:
        print(f"Rejected line {item[0]}: {item[2]}")
    print("Reports saved in:", out.resolve())
    return report_rows, total, rejected_lines

if __name__ == "__main__":
    process_mess_file(Path(__file__).parent / "input" / "mess_oct.txt",
                      Path(__file__).parent / "output")
