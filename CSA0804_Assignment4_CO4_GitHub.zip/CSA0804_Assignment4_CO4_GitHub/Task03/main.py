from pathlib import Path

class InvalidRecord(Exception):
    """Raised when an attendance line does not match the required format."""

def parse_line(line):
    parts = [part.strip() for part in line.strip().split(",")]
    if len(parts) != 3:
        raise InvalidRecord(f"expected 3 fields, found {len(parts)}")
    reg_no, date, status = parts
    if not reg_no or not date:
        raise InvalidRecord("register number and date cannot be empty")
    if status not in ("P", "A"):
        raise InvalidRecord(f"invalid status '{status}'")
    return reg_no, date, status

def summarise(path):
    present = absent = 0
    errors, valid_records = [], 0
    try:
        with open(path, "r", encoding="utf-8") as file:
            for line_no, line in enumerate(file, start=1):
                if not line.strip():
                    continue
                try:
                    reg_no, date, status = parse_line(line)
                except InvalidRecord as error:
                    errors.append((line_no, str(error)))
                    continue
                else:
                    valid_records += 1
                    if status == "P":
                        present += 1
                    else:
                        absent += 1
            if valid_records == 0:
                print("Warning: input file contains no valid attendance records.")
    except FileNotFoundError:
        print(f"File not found: {path}")
    except PermissionError:
        print(f"Permission denied: {path}")
    except UnicodeDecodeError:
        print(f"Input is not valid UTF-8: {path}")
    else:
        print("File read completed.")
    finally:
        print("Attendance file processing attempt finished.")
    return present, absent, errors

if __name__ == "__main__":
    path = Path(__file__).parent / "input" / "attendance.txt"
    p, a, errors = summarise(path)
    print("Present:", p)
    print("Absent:", a)
    print("Invalid records:", len(errors))
    for line_no, reason in errors:
        print(f"Line {line_no}: {reason}")
