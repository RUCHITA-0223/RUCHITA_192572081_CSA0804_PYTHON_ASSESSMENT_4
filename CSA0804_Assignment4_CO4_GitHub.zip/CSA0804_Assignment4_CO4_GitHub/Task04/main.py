from pathlib import Path
from datetime import datetime

def save_returns(books, log_path):
    log_path = Path(log_path)
    log_path.parent.mkdir(parents=True, exist_ok=True)
    with log_path.open("a", encoding="utf-8") as log:
        for book in books:
            title = book.strip()
            if title:
                log.write(title + "\n")

def process(day_file, log_path):
    try:
        with open(day_file, "r", encoding="utf-8") as source:
            books = source.readlines()
        save_returns(books, log_path)
        print(f"Processed {Path(day_file).name}: {len([b for b in books if b.strip()])} returns")
    except FileNotFoundError:
        message = f"{datetime.now().isoformat(timespec='seconds')} | missing input: {day_file}\n"
        Path(log_path).parent.mkdir(parents=True, exist_ok=True)
        with open(Path(log_path).with_name("errors.log"), "a", encoding="utf-8") as error_log:
            error_log.write(message)
        print("Missing file:", day_file)
    except (PermissionError, UnicodeDecodeError, OSError) as error:
        print(f"Could not process {day_file}: {error}")

if __name__ == "__main__":
    base = Path(__file__).parent
    output = base / "output"
    output.mkdir(exist_ok=True)
    log = output / "returns.log"
    if log.exists():
        log.unlink()  # Clean demonstration run; save_returns itself uses append mode.
    for filename in ("day1.txt", "day2.txt", "day3.txt"):
        process(base / "input" / filename, log)
    print("\nFinal return log:")
    print(log.read_text(encoding="utf-8"))
