import csv
from pathlib import Path

def process_month(folder, output_dir):
    folder, output_dir = Path(folder), Path(output_dir)
    attendance, damaged = {}, []
    files = sorted(folder.glob("*.txt"))
    for file_path in files:
        try:
            with file_path.open("r", encoding="utf-8") as source:
                for line_no, line in enumerate(source, start=1):
                    if not line.strip():
                        continue
                    parts = [part.strip() for part in line.rstrip("\n").split(",")]
                    if len(parts) != 3:
                        damaged.append((file_path.name, line_no, line.rstrip(), "Expected 3 fields"))
                        continue
                    reg_no, date, status = parts
                    if not reg_no or not date or status not in ("P", "A"):
                        damaged.append((file_path.name, line_no, line.rstrip(), "Empty field or invalid status"))
                        continue
                    attendance.setdefault(reg_no, {"P": 0, "A": 0})
                    attendance[reg_no][status] += 1
        except (FileNotFoundError, PermissionError, UnicodeDecodeError, OSError) as error:
            damaged.append((file_path.name, "-", "", f"File error: {error}"))

    output_dir.mkdir(parents=True, exist_ok=True)
    below = []
    with (output_dir / "attendance_summary.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["Register Number", "Present", "Total Valid Days", "Attendance Percentage"])
        for reg_no, counts in sorted(attendance.items()):
            total = counts["P"] + counts["A"]
            percentage = counts["P"] / total * 100 if total else 0
            writer.writerow([reg_no, counts["P"], total, f"{percentage:.2f}"])
            if percentage < 75:
                below.append((reg_no, percentage))
    with (output_dir / "below_75.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["Register Number", "Attendance Percentage"])
        writer.writerows((reg, f"{pct:.2f}") for reg, pct in below)
    with (output_dir / "damaged_lines.log").open("w", encoding="utf-8") as f:
        for row in damaged:
            f.write(" | ".join(map(str, row)) + "\n")

    print("MONTHLY ATTENDANCE PROCESSOR")
    print("Daily files found:", len(files))
    print("Students processed:", len(attendance))
    print("Students below 75%:", len(below))
    for reg, pct in below:
        print(f"{reg}: {pct:.2f}%")
    print("Damaged records:", len(damaged))
    print("Output folder:", output_dir.resolve())
    return attendance, below, damaged

if __name__ == "__main__":
    base = Path(__file__).parent
    process_month(base / "input", base / "output")
