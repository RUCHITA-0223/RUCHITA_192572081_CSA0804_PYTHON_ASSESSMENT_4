def percentage(present, total):
    return present / total * 100 if total else 0
def absent_three_consecutive(statuses):
    streak = 0
    for status in statuses:
        streak = streak + 1 if status == "A" else 0
        if streak >= 3:
            return True
    return False
