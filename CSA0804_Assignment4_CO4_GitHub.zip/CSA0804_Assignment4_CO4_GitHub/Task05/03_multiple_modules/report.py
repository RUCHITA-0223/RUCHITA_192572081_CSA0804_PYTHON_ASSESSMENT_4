def write_report(rows, path):
    with open(path, "w", encoding="utf-8") as file:
        for row in rows:
            file.write(str(row) + "\n")
