from pathlib import Path
import reader, stats, report
if __name__ == "__main__":
    base = Path(__file__).parent
    records = reader.read_records(base / "attendance.csv")
    value = stats.percentage(sum(r[2] == "P" for r in records), len(records))
    report.write_report([f"Valid records: {len(records)}", f"Attendance: {value:.2f}%"], base / "summary.txt")
    print(f"Multiple-module design | records={len(records)} | attendance={value:.2f}%")
    print("Three consecutive absences test:", stats.absent_three_consecutive(["P", "A", "A", "A"]))
