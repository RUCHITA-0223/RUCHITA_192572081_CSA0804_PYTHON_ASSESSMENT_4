from pathlib import Path
def read_records(path):
    rows = []
    with open(path, encoding="utf-8") as file:
        for line in file:
            parts = [x.strip() for x in line.strip().split(",")]
            if len(parts) == 3 and parts[0] and parts[2] in ("P", "A"):
                rows.append(parts)
    return rows
def percentage(present, total):
    return present / total * 100 if total else 0
def write_report(rows, path):
    with open(path, "w", encoding="utf-8") as file:
        for row in rows:
            file.write(str(row) + "\n")
if __name__ == "__main__":
    base = Path(__file__).parent
    data = read_records(base / "attendance.csv")
    p = sum(row[2] == "P" for row in data)
    value = percentage(p, len(data))
    write_report([f"Valid records: {len(data)}", f"Attendance: {value:.2f}%"], base / "summary.txt")
    print("Single-script attendance utility")
    print(f"Valid records: {len(data)} | Attendance: {value:.2f}%")
