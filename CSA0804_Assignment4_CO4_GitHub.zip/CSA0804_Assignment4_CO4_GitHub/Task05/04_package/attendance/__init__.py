"""Reusable attendance processing package."""
