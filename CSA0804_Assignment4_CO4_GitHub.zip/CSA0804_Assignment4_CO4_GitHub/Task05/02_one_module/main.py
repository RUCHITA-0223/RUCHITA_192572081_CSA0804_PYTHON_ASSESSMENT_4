from pathlib import Path
import attendance_utils as au
if __name__ == "__main__":
    base = Path(__file__).parent
    records = au.read_records(base / "attendance.csv")
    value = au.percentage(sum(r[2] == "P" for r in records), len(records))
    au.write_report([f"Valid records: {len(records)}", f"Attendance: {value:.2f}%"], base / "summary.txt")
    print(f"One-module design | records={len(records)} | attendance={value:.2f}%")
